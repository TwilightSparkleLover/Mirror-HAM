/*
    Document written by using Dev C++ 4.9.7.0
    Download it as http://www.bloodshed.net/
*/
/*
    ACT to GBA 
    
    This program converts ACT (Adobe Color Table) files into C/C++ Sourcecode.
    The format of an ACT file is easy.
    
    It is built as follows:
    
    R, G, B, R, G, B, R, G, B ...
    
    Where R, G, B are each one byte in size.
    An ACT file contains 256 RGB entries.
    
    It does not have any ident header or something like that.

    --------------------------------------------------------------------------------------

    This program is freeware. You are allowed to change the source
    and distribute a new version in source and/or binary form as long as
    every ACT2GBA developer is still mentioned.
    
    
    Version    Date          Author             Log
    --------------------------------------------------------------------------------------
    0.1        28/12/2002    Peter Schraut      Inital Release
    0.2        22/02/2003    Peter Schraut      ACT2GBA Version is saved in the output file
                                                Commentated the source
   
*/
#include <stdio.h>
#include <string.h>

/*
    Version of this program
    Change the version here
*/
#define APP_VERSION_STR     "0.2"

/*
    Developers of this program
*/
#define APP_DISTRUBUTERS    "\t Peter Schraut (www.console-dev.de)\n"

/*
    Users of ACT2GBA must accept this disclaimer of warranty ;-) 
*/
#define APP_DISCLAIMER "\
'ACT2GBA Utility' is supplied as is.\n\
The author(s) disclaims all warranties, expressed or implied,\n\
including, without limitation the warranties of merchantability\n\
and of fitness for any purpose.\n\n\
The author(s) assumes no liability for damages, direct or\n\
consequential, which may result from the use of 'ACT2GBA Utility'.\n\n\
------------------------------------------------------------------\n\n"

/*
    Structure to hold the Converted Palette
*/
typedef struct TGbaPalette
{
    unsigned short Colors[256];
}TGbaPalette;

/*
    Structure to hold a RGB Trible
*/
typedef struct TRGB
{
    unsigned char R,G,B;
}TRGB;

/*
    Some macros to convert RGB (24bit) to 15 bit BGR format
    Borrowed from the file of HAM SDK "mygba.h" made by Emanuel Schleussinger
*/
#define RGB(r,g,b)              ((((b)>>3)<<10)+(((g)>>3)<<5)+((r)>>3))
#define RGB_SET(r,g,b)          (((b)<<10)+((g)<<5)+(r));

#define RGB_GET_R_VALUE(rgb)    ((rgb & 0x001f) << 3)
#define RGB_GET_G_VALUE(rgb)    (((rgb >> 5) & 0x001f) << 3)
#define RGB_GET_B_VALUE(rgb)    (((rgb >> 10) & 0x001f) << 3)

/*
    Reads a ACT file and converts the palette into an extra
    buffer specified in pGbaPalette.
    
    Arg:
        pACTFileName    :   Filename of ACT you want to convert
        pGbaPalette     :   Pointer to TGbaPalette structure where
                            the converted valued will become stored in
                            
    Ret:
        -1              :   Can't open file.
        0               :   Success
*/
int ConvertACT2GBA(char *pACTFileName, TGbaPalette *pGbaPalette)
{
    int iRead=0;
    FILE *pInFile=NULL;
    int Count=0;
    TRGB rgb;

    // Open the file
    pInFile = fopen(pACTFileName, "rb");
    if( NULL == pInFile )
    {
        printf("***ERROR: can't open '%s' ...", pACTFileName);
        return -1;
    }

    printf("reading '%s' ... ", pACTFileName);
    
    // Read file
    while((iRead=fread(&rgb, sizeof(TRGB), 1, pInFile)) > 0)
    {
        // Store converted BGR Value into GbaPalette Structure
        pGbaPalette->Colors[Count++] = RGB(rgb.R,rgb.G,rgb.B);
    }

    // Close again
    fclose(pInFile);

    return 0;
}

/*
    Saves a TGbaPalette Struture as a file in c/c++ source format
    
    Arg:
        pName       :   Name of file you want to save
        pGbaPalette :   Palette to save
        
    Ret:
        -1          :   Can't create file
        0           :   Success
*/
int SaveAsC(char *pName, TGbaPalette *pGbaPalette)
{
    int i=0, x,y;
    FILE *pOutFile=NULL;
    char Line[1024];

    // Create file, replace if it exists
    pOutFile = fopen(pName, "wb+");
    if( NULL == pOutFile )
    {
        printf("***ERROR: can't create '%s' ...",pName);
        return -1;
    }

    // Print a little header
    fprintf(pOutFile, "/*\n");
    fprintf(pOutFile, "\t Created by using ACT2GBA %s\n", APP_VERSION_STR);
    fprintf(pOutFile, "\t http://www.console-dev.de\n");
    fprintf(pOutFile, "*/\n\n");
    
    fprintf(pOutFile, "const unsigned short Palette[256]={\n");
    printf("converting ... ");
    
    // Convert buffer
    for(y=0; y<32; y++)
    {
        for(x=0; x<8; x++)
        {
            fprintf(pOutFile, "0x%.4x, ", pGbaPalette->Colors[i++]);
        }
        fprintf(pOutFile, "\n");
    }

    fprintf(pOutFile, "};\n");
    fclose(pOutFile);

    return 0;
}

/*
    Show Developers in console
*/
void ShowDevelopers(void)
{
    printf("\n");
    printf("Developers:\n");
    printf(APP_DISTRUBUTERS);
}

/*
    Application entrypoint
*/
int main(int argc, char *argv[])
{
    TGbaPalette Palette;
    char OutName[256];

    // Show program name
    printf("=====================\n");
    printf("= ACT2GBA Converter =\n");
    printf("=====================\n\n");

    // Enough arguments specified?
    if(argc < 2)
    {
        printf(APP_DISCLAIMER);
        
        printf("ACT2GBA converts Adobe ColorTable files (*.act)\n");
        printf("into GBA 15bit BGR format and output it as C/C++ source.\n");
        printf("*.ACT files can be created/edited/exported with Adobe Photoshop\n\n");

        printf("usage..: act2gba.exe <inputfile>\n");
        printf("example: act2gba.exe palette.act\n\n");
        
        ShowDevelopers();

        return -1;
    }

    // Make sure the conversion is ok
    if(-1 == ConvertACT2GBA(argv[1], &Palette)) return -1;

    // Add a ".c" extension to the filename
    strcpy(OutName, argv[1]);
    strcat(OutName, ".c");

    // Save it as C file
    if(0 == SaveAsC(OutName, &Palette))
    {
        printf("ok\n");
    }

    return 0;
}
